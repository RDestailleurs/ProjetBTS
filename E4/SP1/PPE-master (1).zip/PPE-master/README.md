# PPEproject
Projet PPE gaston berger 2SLAM année 2020/2021

Index : l'index contient la page d'accueil du site, elle contient un module de connexion

page formulaire.css est le css pour les pages inscription et connexion
page style.css est le css pour le menu 

verification.php est la suite de connexion.php elle sert a verifier si la connexion peut avoir lieu ou non
verification redirige ensuite sur compte.php
inscription.php sert a s'inscrire et le traitement de l'inscription se fait sur la meme page

compte verifie si le client est connecté si c'est le cas il affiche sa page compte et sinon il le redirige vers l'accueil 
mdp.php sert a modifier son motdepasse 