<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link type="text/css" rel="stylesheet" href="style.css">
</head>
<body>      
    <div class="menu">
  		<a class="active" href="index.php">Accueil</a>
  		<a href="#reserv">Reservation</a>
  		<a href="liaison.php">Liaisons</a>
		<a href="#traverset">Traversée</a>
		<a class="compte" href="compte.php">Compte</a>
	</div>    
</body>
</html>
